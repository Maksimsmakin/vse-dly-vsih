import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CatalogPage } from './components/CatalogPage';
import { CheckoutSection } from './components/CheckoutSection';
import { Footer } from './components/Footer';
import { Category, CartItem, FormData, Language } from './types';
import { translations } from './data/translations';
import { categories } from './data/categories';

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [language, setLanguage] = useState<Language>("ru");
  const [currentPage, setCurrentPage] = useState<'home' | 'catalog'>('home');
  const [formData, setFormData] = useState<FormData>({
    name: "",
    phone: "",
    address: ""
  });

  const t = translations[language];

  const addToCart = (item: Category) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCart(prev => prev.map(cartItem => 
        cartItem.id === item.id 
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart(prev => [...prev, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const submitOrder = () => {
    console.log("🛒 Заказ отправлен:", {
      товары: cart,
      клиент: formData,
    });
    alert(t.checkout.thankYou);
    setCart([]);
    setFormData({ name: "", phone: "", address: "" });
  };

  if (currentPage === 'catalog') {
    return (
      <div className="min-h-screen bg-white">
        <Header 
          cart={cart} 
          language={language} 
          setLanguage={setLanguage}
          onNavigate={setCurrentPage}
        />
        <CatalogPage />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header 
        cart={cart} 
        language={language} 
        setLanguage={setLanguage}
        onNavigate={setCurrentPage}
      />
      
      <HeroSection language={language} />
      
      {/* Categories Section */}
      <section id="categories" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              {t.categories.title}
            </h3>
            <div className="w-24 h-1 bg-black mx-auto"></div>
          </div>
          
          <div className="text-center">
            <button
              onClick={() => setCurrentPage('catalog')}
              className="inline-flex items-center px-8 py-4 bg-black text-white font-semibold rounded-full shadow-xl hover:bg-gray-800 hover:scale-105 transition-all duration-300"
            >
              Переглянути повний каталог
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      <CheckoutSection
        cart={cart}
        formData={formData}
        setFormData={setFormData}
        onSubmitOrder={submitOrder}
        onRemoveFromCart={removeFromCart}
        translations={t}
      />

      <Footer language={language} />
    </div>
  );
}

export default App;