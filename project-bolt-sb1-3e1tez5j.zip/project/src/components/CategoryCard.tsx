import React from 'react';
import { Plus } from 'lucide-react';
import { Category } from '../types';

interface CategoryCardProps {
  category: Category;
  onAddToCart: (item: Category) => void;
  addToCartText: string;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ 
  category, 
  onAddToCart, 
  addToCartText 
}) => {
  return (
    <div className="group bg-white shadow-lg rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
      <div className="relative overflow-hidden">
        <img
          src={category.image}
          alt={category.title}
          className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      </div>
      
      <div className="p-6">
        <h4 className="font-bold text-xl mb-3 text-gray-900">{category.title}</h4>
        <p className="text-gray-600 mb-6 leading-relaxed">{category.desc}</p>
        
        <button
          onClick={() => onAddToCart(category)}
          className="w-full flex items-center justify-center px-6 py-3 bg-black text-white rounded-full hover:bg-gray-800 transition-all duration-300 hover:shadow-lg group/button"
        >
          <Plus className="w-4 h-4 mr-2 group-hover/button:rotate-90 transition-transform duration-300" />
          {addToCartText}
        </button>
      </div>
    </div>
  );
};