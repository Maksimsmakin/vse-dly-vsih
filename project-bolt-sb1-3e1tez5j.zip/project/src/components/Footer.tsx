import React from 'react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const t = translations[language];

  return (
    <footer className="bg-black text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            {t.brand}
          </h3>
          <p className="text-gray-400 mb-6">Premium dropshipping solutions</p>
          <div className="border-t border-gray-800 pt-6">
            <p className="text-sm text-gray-500">{t.footer.copyright}</p>
          </div>
        </div>
      </div>
    </footer>
  );
};