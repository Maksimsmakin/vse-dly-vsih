import React from 'react';
import { Search, Filter, Grid, List, Star, Tag } from 'lucide-react';
import { FilterState, Product } from '../types';
import { products } from '../data/products';
import { FilterSidebar } from './FilterSidebar';
import { getPriceRange } from '../data/products';

interface ProductGridProps {
  selectedCategory?: string;
}

export const ProductGrid: React.FC<ProductGridProps> = ({ selectedCategory }) => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [viewMode, setViewMode] = React.useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = React.useState('popularity');
  const [showFilters, setShowFilters] = React.useState(false);
  const [filters, setFilters] = React.useState<FilterState>({
    manufacturers: [],
    priceRange: getPriceRange(),
    onlyDiscounted: false
  });

  // Filter and search products
  const filteredProducts = React.useMemo(() => {
    let filtered = products.filter(product => {
      // Search filter
      if (searchTerm && !product.name.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }
      
      // Category filter
      if (selectedCategory && product.subcategoryId !== selectedCategory && product.categoryId !== selectedCategory) {
        return false;
      }
      
      // Manufacturer filter
      if (filters.manufacturers.length > 0 && !filters.manufacturers.includes(product.manufacturer)) {
        return false;
      }
      
      // Price range filter
      if (product.price < filters.priceRange.min || product.price > filters.priceRange.max) {
        return false;
      }
      
      // Discount filter
      if (filters.onlyDiscounted && !product.discount) {
        return false;
      }
      
      return true;
    });
    
    // Sort products
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        // For demo purposes, sort by id (newest first)
        filtered.sort((a, b) => Number(b.id) - Number(a.id));
        break;
      default:
        // popularity - keep original order
        break;
    }
    
    return filtered;
  }, [searchTerm, selectedCategory, filters, sortBy]);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <FilterSidebar
        filters={filters}
        onFiltersChange={setFilters}
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
      />
      
      <div className="flex-1 p-6">
      {/* Search and Filter Bar */}
      <div className="mb-6">
        <div className="flex items-center space-x-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Пошук товарів..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>
          <button 
          {product.discount && (
            <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-lg text-xs font-semibold flex items-center">
              <Tag className="w-3 h-3 mr-1" />
              -{product.discount}%
            </div>
          )}
          
          <div className="absolute top-2 right-2 bg-white bg-opacity-90 px-2 py-1 rounded-lg text-xs text-gray-600">
            {product.manufacturer}
          </div>
        </div>
            onClick={() => setShowFilters(true)}
            className="lg:hidden flex items-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Filter className="w-5 h-5" />
            <span>Фільтри</span>
          </button>
          <div className="flex border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-3 ${viewMode === 'grid' ? 'bg-blue-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'} transition-colors`}
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-3 ${viewMode === 'list' ? 'bg-blue-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'} transition-colors`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <p className="text-gray-600">
            Знайдено {filteredProducts.length} товарів
            {selectedCategory && <span className="ml-2 text-blue-600">в обраній категорії</span>}
          </p>
          <select 
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            <option>За популярністю</option>
            <option value="price-low">За ціною: від дешевих</option>
            <option value="price-high">За ціною: від дорогих</option>
            <option value="rating">За рейтингом</option>
            <option value="newest">Новинки</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      <div className={`grid gap-6 ${
        viewMode === 'grid' 
          ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
          : 'grid-cols-1'
      }`}>
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden ${
              viewMode === 'list' ? 'flex' : ''
            }`}
          >
            <div className={`${viewMode === 'list' ? 'w-48 flex-shrink-0' : ''}`}>
              <img
                src={product.image}
                alt={product.name}
                className={`w-full object-cover ${
                  viewMode === 'list' ? 'h-32' : 'h-48'
                }`}
              />
            </div>
            
            <div className="p-4 flex-1">
              <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
              <div className="flex items-center mb-2">
                <div className="flex items-center">
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i < product.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                    />
                  ))}
                  <span className="text-sm text-gray-500 ml-2">({product.reviews})</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between mb-2">
                <div className="flex flex-col">
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">
                      {product.originalPrice.toLocaleString()} ₴
                    </span>
                  )}
                  <span className="text-xl font-bold text-blue-600">
                    {product.price.toLocaleString()} ₴
                  </span>
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  В кошик
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
            <Search className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Товари не знайдено</h3>
          <p className="text-gray-600">Спробуйте змінити фільтри або пошуковий запит</p>
        </div>
      )}

      {/* Pagination */}
      {filteredProducts.length > 0 && (
        <div className="mt-8 flex justify-center">
        <div className="flex space-x-2">
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            Попередня
          </button>
          {[1, 2, 3, 4, 5].map((page) => (
            <button
              key={page}
              className={`px-3 py-2 rounded-lg transition-colors ${
                page === 1 
                  ? 'bg-blue-600 text-white' 
                  : 'border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {page}
            </button>
          ))}
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            Наступна
          </button>
        </div>
      </div>
      )}
      </div>
    </div>
  );
};