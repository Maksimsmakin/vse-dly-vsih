import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Package } from 'lucide-react';
import { Category } from '../types';

interface SidebarProps {
  categories: Category[];
  onCategorySelect: (categoryId: string) => void;
  selectedCategory?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  categories, 
  onCategorySelect, 
  selectedCategory 
}) => {
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  return (
    <div className="w-80 bg-white shadow-lg h-full overflow-y-auto border-r border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Є Все Для Всіх</h2>
            <p className="text-sm text-gray-500">Інтернет-магазин</p>
          </div>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Каталог товарів</h3>
        
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category.id} className="border border-gray-200 rounded-lg overflow-hidden">
              <button
                onClick={() => toggleCategory(category.id)}
                className={`w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 transition-colors ${
                  selectedCategory === category.id ? 'bg-blue-50 border-blue-200' : ''
                }`}
              >
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 text-sm leading-tight">
                    {category.title}
                  </h4>
                  <p className="text-xs text-gray-500 mt-1">
                    {category.subcategories?.length || 0} підкатегорій
                  </p>
                </div>
                {expandedCategories.includes(category.id) ? (
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                )}
              </button>
              
              {expandedCategories.includes(category.id) && category.subcategories && (
                <div className="bg-gray-50 border-t border-gray-200">
                  {category.subcategories.map((subcategory) => (
                    <button
                      key={subcategory.id}
                      onClick={() => onCategorySelect(subcategory.id)}
                      className="w-full flex items-center justify-between p-3 text-left hover:bg-white transition-colors border-b border-gray-100 last:border-b-0"
                    >
                      <span className="text-sm text-gray-700">{subcategory.title}</span>
                      <span className="text-xs text-gray-500 bg-gray-200 px-2 py-1 rounded-full">
                        {subcategory.count}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};