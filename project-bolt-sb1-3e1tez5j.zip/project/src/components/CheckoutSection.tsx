import React from 'react';
import { ShoppingBag, Trash2 } from 'lucide-react';
import { CartItem, FormData } from '../types';

interface CheckoutSectionProps {
  cart: CartItem[];
  formData: FormData;
  setFormData: (data: FormData) => void;
  onSubmitOrder: () => void;
  onRemoveFromCart: (index: number) => void;
  translations: any;
}

export const CheckoutSection: React.FC<CheckoutSectionProps> = ({
  cart,
  formData,
  setFormData,
  onSubmitOrder,
  onRemoveFromCart,
  translations: t
}) => {
  return (
    <section id="order" className="py-20 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-12">
          <ShoppingBag className="w-12 h-12 mx-auto mb-4 text-gray-700" />
          <h3 className="text-3xl font-bold text-gray-900">{t.checkout.title}</h3>
        </div>
        
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {cart.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <ShoppingBag className="w-12 h-12 text-gray-400" />
              </div>
              <p className="text-gray-600 text-lg">{t.checkout.emptyCart}</p>
            </div>
          ) : (
            <>
              <div className="mb-8">
                <h4 className="font-semibold text-lg mb-4 text-gray-900">Товары в корзине:</h4>
                <ul className="space-y-3">
                  {cart.map((item, i) => (
                    <li key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <span className="font-medium">{item.title}</span>
                      <button
                        onClick={() => onRemoveFromCart(i)}
                        className="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder={t.checkout.namePlaceholder}
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent transition-all outline-none"
                />
                <input
                  type="tel"
                  placeholder={t.checkout.phonePlaceholder}
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent transition-all outline-none"
                />
                <input
                  type="text"
                  placeholder={t.checkout.addressPlaceholder}
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent transition-all outline-none"
                />
                
                <button
                  onClick={onSubmitOrder}
                  disabled={!formData.name || !formData.phone || !formData.address}
                  className="w-full py-4 bg-black text-white rounded-lg hover:bg-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 font-semibold text-lg hover:shadow-lg"
                >
                  {t.checkout.confirmOrder}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};