import React, { useState } from 'react';
import { Filter, X, ChevronDown, ChevronUp } from 'lucide-react';
import { FilterState } from '../types';
import { getManufacturers, getPriceRange } from '../data/products';

interface FilterSidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onFiltersChange,
  isOpen,
  onClose
}) => {
  const [expandedSections, setExpandedSections] = useState<string[]>(['manufacturers', 'price', 'discounts']);
  const manufacturers = getManufacturers();
  const priceRange = getPriceRange();

  const toggleSection = (section: string) => {
    setExpandedSections(prev =>
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const handleManufacturerChange = (manufacturer: string, checked: boolean) => {
    const newManufacturers = checked
      ? [...filters.manufacturers, manufacturer]
      : filters.manufacturers.filter(m => m !== manufacturer);
    
    onFiltersChange({
      ...filters,
      manufacturers: newManufacturers
    });
  };

  const handlePriceChange = (type: 'min' | 'max', value: number) => {
    onFiltersChange({
      ...filters,
      priceRange: {
        ...filters.priceRange,
        [type]: value
      }
    });
  };

  const clearAllFilters = () => {
    onFiltersChange({
      manufacturers: [],
      priceRange: { min: priceRange.min, max: priceRange.max },
      onlyDiscounted: false
    });
  };

  const activeFiltersCount = 
    filters.manufacturers.length + 
    (filters.onlyDiscounted ? 1 : 0) +
    (filters.priceRange.min !== priceRange.min || filters.priceRange.max !== priceRange.max ? 1 : 0);

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Filter Sidebar */}
      <div className={`
        fixed lg:relative top-0 left-0 h-full w-80 bg-white shadow-lg z-50 transform transition-transform duration-300 overflow-y-auto
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Filter className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-bold text-gray-900">Фільтри</h2>
              {activeFiltersCount > 0 && (
                <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
                  {activeFiltersCount}
                </span>
              )}
            </div>
            <button
              onClick={onClose}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {activeFiltersCount > 0 && (
            <button
              onClick={clearAllFilters}
              className="mt-3 text-sm text-blue-600 hover:text-blue-800 transition-colors"
            >
              Очистити всі фільтри
            </button>
          )}
        </div>

        <div className="p-4 space-y-4">
          {/* Manufacturers Filter */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('manufacturers')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <span className="font-semibold text-gray-900">Виробник</span>
              {expandedSections.includes('manufacturers') ? (
                <ChevronUp className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              )}
            </button>
            
            {expandedSections.includes('manufacturers') && (
              <div className="p-4 bg-white max-h-60 overflow-y-auto">
                <div className="space-y-3">
                  {manufacturers.map((manufacturer) => (
                    <label key={manufacturer} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.manufacturers.includes(manufacturer)}
                        onChange={(e) => handleManufacturerChange(manufacturer, e.target.checked)}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">{manufacturer}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Price Range Filter */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('price')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <span className="font-semibold text-gray-900">Ціна</span>
              {expandedSections.includes('price') ? (
                <ChevronUp className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              )}
            </button>
            
            {expandedSections.includes('price') && (
              <div className="p-4 bg-white">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="flex-1">
                      <label className="block text-xs text-gray-600 mb-1">Від</label>
                      <input
                        type="number"
                        value={filters.priceRange.min}
                        onChange={(e) => handlePriceChange('min', Number(e.target.value))}
                        min={priceRange.min}
                        max={priceRange.max}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-xs text-gray-600 mb-1">До</label>
                      <input
                        type="number"
                        value={filters.priceRange.max}
                        onChange={(e) => handlePriceChange('max', Number(e.target.value))}
                        min={priceRange.min}
                        max={priceRange.max}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>{priceRange.min.toLocaleString()} ₴</span>
                      <span>{priceRange.max.toLocaleString()} ₴</span>
                    </div>
                    <input
                      type="range"
                      min={priceRange.min}
                      max={priceRange.max}
                      value={filters.priceRange.min}
                      onChange={(e) => handlePriceChange('min', Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                    />
                    <input
                      type="range"
                      min={priceRange.min}
                      max={priceRange.max}
                      value={filters.priceRange.max}
                      onChange={(e) => handlePriceChange('max', Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Discounts Filter */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('discounts')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <span className="font-semibold text-gray-900">Знижки</span>
              {expandedSections.includes('discounts') ? (
                <ChevronUp className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              )}
            </button>
            
            {expandedSections.includes('discounts') && (
              <div className="p-4 bg-white">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.onlyDiscounted}
                    onChange={(e) => onFiltersChange({
                      ...filters,
                      onlyDiscounted: e.target.checked
                    })}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Тільки товари зі знижкою</span>
                </label>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};