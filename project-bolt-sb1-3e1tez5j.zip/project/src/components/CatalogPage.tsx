import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { ProductGrid } from './ProductGrid';
import { categories } from '../data/categories';

export const CatalogPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>();

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
        <Sidebar 
          categories={categories}
          onCategorySelect={handleCategorySelect}
          selectedCategory={selectedCategory}
        />
        <ProductGrid selectedCategory={selectedCategory} />
    </div>
  );
};