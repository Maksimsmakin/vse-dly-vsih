import React from 'react';
import { ShoppingCart, Globe } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface HeaderProps {
  cart: any[];
  language: Language;
  setLanguage: (lang: Language) => void;
  onNavigate?: (page: 'home' | 'catalog') => void;
}

export const Header: React.FC<HeaderProps> = ({ cart, language, setLanguage, onNavigate }) => {
  const t = translations[language];

  return (
    <header className="bg-black text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            {t.brand}
          </h1>
          <nav className="hidden md:flex space-x-6">
            <button 
              onClick={() => onNavigate?.('home')}
              className="hover:text-gray-300 transition-colors"
            >
              {t.nav.home}
            </button>
            <button 
              onClick={() => onNavigate?.('catalog')}
              className="hover:text-gray-300 transition-colors"
            >
              {t.nav.catalog}
            </button>
          </nav>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="w-5 h-5" />
            <span className="bg-white text-black px-2 py-1 rounded-full text-sm font-medium">
              {cart.length}
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Globe className="w-4 h-4" />
            <select 
              value={language} 
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="bg-transparent border border-gray-600 rounded px-2 py-1 text-sm outline-none focus:border-white transition-colors"
            >
              <option value="uk" className="bg-black">🇺🇦 UK</option>
              <option value="ru" className="bg-black">🇷🇺 RU</option>
              <option value="en" className="bg-black">🇬🇧 EN</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};