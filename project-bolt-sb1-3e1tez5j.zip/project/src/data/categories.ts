import { Category } from '../types';

export const categories: Category[] = [
  {
    id: "1",
    title: "Ноутбуки, планшети та комп'ютерна периферія",
    desc: "Сучасна комп'ютерна техніка та аксесуари",
    image: "https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "1-1", title: "Ноутбуки", count: 245 },
      { id: "1-2", title: "Комп'ютери, неттопи, моноблоки", count: 189 },
      { id: "1-3", title: "Монітори", count: 156 },
      { id: "1-4", title: "Планшети", count: 98 },
      { id: "1-5", title: "Офісна техніка", count: 234 },
      { id: "1-6", title: "Мережеве обладнання", count: 87 },
      { id: "1-7", title: "Аксесуари для електроніки", count: 456 },
      { id: "1-8", title: "Графічні планшети та аксесуари", count: 67 },
      { id: "1-9", title: "Комп'ютерні комплектуючі", count: 345 },
      { id: "1-10", title: "Програмне забезпечення", count: 123 },
      { id: "1-11", title: "Серверне обладнання", count: 45 },
      { id: "1-12", title: "Товари для геймерів", count: 234 },
      { id: "1-13", title: "Інтерактивне обладнання", count: 56 }
    ]
  },
  {
    id: "2",
    title: "Смартфони, ТВ і електроніка",
    desc: "Мобільні пристрої та електронна техніка",
    image: "https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "2-1", title: "Мобільні телефони", count: 189 },
      { id: "2-2", title: "Аксесуари для телевізорів", count: 145 },
      { id: "2-3", title: "Телевізори", count: 98 },
      { id: "2-4", title: "Аксесуари до мобільних телефонів і смартфонів", count: 567 },
      { id: "2-5", title: "Портативна електроніка", count: 234 },
      { id: "2-6", title: "Фото та відео", count: 156 },
      { id: "2-7", title: "Носимі гаджети", count: 89 },
      { id: "2-8", title: "Навушники та аксесуари", count: 234 },
      { id: "2-9", title: "Проекційне обладнання", count: 45 },
      { id: "2-10", title: "Аудіотехніка", count: 123 },
      { id: "2-11", title: "Повербанки та зарядні станції", count: 178 }
    ]
  },
  {
    id: "3",
    title: "Побутова техніка",
    desc: "Техніка для дому та побуту",
    image: "https://images.pexels.com/photos/4686822/pexels-photo-4686822.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "3-1", title: "Велика побутова техніка", count: 156 },
      { id: "3-2", title: "Вбудована техніка", count: 89 },
      { id: "3-3", title: "Дрібна побутова техніка", count: 345 },
      { id: "3-4", title: "Кліматична техніка", count: 67 }
    ]
  },
  {
    id: "4",
    title: "Напої і продукти",
    desc: "Харчові продукти та напої",
    image: "https://images.pexels.com/photos/264537/pexels-photo-264537.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "4-1", title: "Харчові продукти", count: 1234 },
      { id: "4-2", title: "Алкогольні напої", count: 234 },
      { id: "4-3", title: "Електронні сигарети та аксесуари", count: 89 },
      { id: "4-4", title: "Кальяни та аксесуари", count: 67 },
      { id: "4-5", title: "Тютюнові вироби", count: 45 }
    ]
  },
  {
    id: "5",
    title: "Одяг і взуття",
    desc: "Модний одяг та взуття для всієї родини",
    image: "https://images.pexels.com/photos/994517/pexels-photo-994517.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "5-1", title: "Одяг", count: 2345 },
      { id: "5-2", title: "Взуття", count: 567 },
      { id: "5-3", title: "Сумки та аксесуари", count: 345 },
      { id: "5-4", title: "Прикраси", count: 234 }
    ]
  },
  {
    id: "6",
    title: "Товари для дому",
    desc: "Все для затишку та комфорту вашого дому",
    image: "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "6-1", title: "Меблі", count: 456 },
      { id: "6-2", title: "Посуд", count: 789 },
      { id: "6-3", title: "Килими", count: 123 },
      { id: "6-4", title: "Годинники", count: 234 },
      { id: "6-5", title: "Сучасний дім", count: 345 },
      { id: "6-6", title: "Домашній текстиль", count: 567 },
      { id: "6-7", title: "Техніка захисту інформації", count: 45 },
      { id: "6-8", title: "Зоотовари", count: 234 },
      { id: "6-9", title: "Декор для дому", count: 456 },
      { id: "6-10", title: "Каміни, печі, сауни", count: 67 },
      { id: "6-11", title: "Господарський інвентар", count: 234 },
      { id: "6-12", title: "Побутова хімія", count: 345 },
      { id: "6-13", title: "Жалюзі, ролети, карнизи", count: 89 },
      { id: "6-14", title: "Мотузкові вироби", count: 56 },
      { id: "6-15", title: "Бродильні виробництва", count: 23 },
      { id: "6-16", title: "Колекціонування", count: 78 },
      { id: "6-17", title: "Церковне начиння", count: 34 }
    ]
  },
  {
    id: "7",
    title: "Краса та здоров'я",
    desc: "Косметика, парфумерія та товари для здоров'я",
    image: "https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "7-1", title: "Косметика та парфумерія", count: 567 },
      { id: "7-2", title: "Манікюр і педикюр", count: 234 },
      { id: "7-3", title: "Засоби для гоління", count: 123 },
      { id: "7-4", title: "Депіляція та шугаринг", count: 89 },
      { id: "7-5", title: "Аптека", count: 345 },
      { id: "7-6", title: "Презервативи", count: 67 },
      { id: "7-7", title: "Одноразова продукція", count: 156 },
      { id: "7-8", title: "Фарбування волосся", count: 98 },
      { id: "7-9", title: "Аксесуари для волосся", count: 234 }
    ]
  },
  {
    id: "8",
    title: "Спорт та туризм",
    desc: "Спортивні товари та туристичне спорядження",
    image: "https://images.pexels.com/photos/416978/pexels-photo-416978.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "8-1", title: "Музичні інструменти та обладнання", count: 234 },
      { id: "8-2", title: "Активний відпочинок, туризм та хобі", count: 456 },
      { id: "8-3", title: "Спортивні товари", count: 567 }
    ]
  },
  {
    id: "9",
    title: "Сантехніка та ремонт",
    desc: "Будівельні матеріали та сантехніка",
    image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "9-1", title: "Інтер'єр та оздоблення", count: 345 },
      { id: "9-2", title: "Сантехніка та меблі для ванної", count: 234 },
      { id: "9-3", title: "Освітлення", count: 456 },
      { id: "9-4", title: "Будівельні матеріали", count: 567 }
    ]
  },
  {
    id: "10",
    title: "Інструменти та автотовари",
    desc: "Інструменти та товари для автомобілів",
    image: "https://images.pexels.com/photos/190574/pexels-photo-190574.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "10-1", title: "Автозвук", count: 123 },
      { id: "10-2", title: "Автоелектроніка", count: 234 },
      { id: "10-3", title: "Автосвітло", count: 156 },
      { id: "10-4", title: "Техдопомога", count: 89 },
      { id: "10-5", title: "Інструменти й обладнання", count: 456 },
      { id: "10-6", title: "Шини та диски", count: 234 },
      { id: "10-7", title: "Автозапчастини", count: 567 },
      { id: "10-8", title: "Авто і мото", count: 345 },
      { id: "10-9", title: "Екстер'єр автомобіля", count: 178 }
    ]
  },
  {
    id: "11",
    title: "Дача, сад, город",
    desc: "Товари для саду та дачі",
    image: "https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "11-1", title: "Садова техніка", count: 123 },
      { id: "11-2", title: "Садовий інвентар", count: 234 },
      { id: "11-3", title: "Садовий декор", count: 156 },
      { id: "11-4", title: "Снігоприбиральна техніка та інвентар", count: 67 },
      { id: "11-5", title: "Системи поливу", count: 89 },
      { id: "11-6", title: "Рослини і догляд за ними", count: 345 },
      { id: "11-7", title: "Упорядкування території", count: 123 },
      { id: "11-8", title: "Басейни та аксесуари", count: 78 },
      { id: "11-9", title: "Дренажні системи", count: 45 },
      { id: "11-10", title: "Садовий інструмент", count: 234 }
    ]
  },
  {
    id: "12",
    title: "Товари для дітей",
    desc: "Все необхідне для дітей різного віку",
    image: "https://images.pexels.com/photos/1148998/pexels-photo-1148998.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "12-1", title: "Для найменших", count: 234 },
      { id: "12-2", title: "Коляски та автокрісла", count: 123 },
      { id: "12-3", title: "Дитяча кімната", count: 345 },
      { id: "12-4", title: "Прогулянки й активний відпочинок", count: 156 },
      { id: "12-5", title: "Товари для мам", count: 189 },
      { id: "12-6", title: "Дитячі іграшки", count: 567 }
    ]
  },
  {
    id: "13",
    title: "Канцтовари, офіс, книги",
    desc: "Канцелярські товари та книги",
    image: "https://images.pexels.com/photos/159751/book-address-book-learning-learn-159751.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "13-1", title: "Живопис і графіка", count: 123 },
      { id: "13-2", title: "Канцелярія", count: 456 },
      { id: "13-3", title: "Хобі, рукоділля і творчість", count: 234 },
      { id: "13-4", title: "Дитяча література", count: 189 },
      { id: "13-5", title: "Книги", count: 567 },
      { id: "13-6", title: "Закладки для книг", count: 45 },
      { id: "13-7", title: "Друкована продукція", count: 123 }
    ]
  },
  {
    id: "14",
    title: "Товари для бізнесу",
    desc: "Професійне обладнання для бізнесу",
    image: "https://images.pexels.com/photos/416405/pexels-photo-416405.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "14-1", title: "Металеві меблі", count: 89 },
      { id: "14-2", title: "Торгове обладнання", count: 156 },
      { id: "14-3", title: "Системи охорони і безпеки", count: 123 },
      { id: "14-4", title: "Обладнання для салонів краси", count: 67 },
      { id: "14-5", title: "Обладнання і матеріали для сувенірної продукції", count: 45 },
      { id: "14-6", title: "Складське обладнання", count: 78 },
      { id: "14-7", title: "Обладнання для тату і перманентного макіяжу", count: 34 },
      { id: "14-8", title: "Організація дорожнього руху", count: 56 },
      { id: "14-9", title: "Сільське господарство", count: 234 },
      { id: "14-10", title: "Клінінгові обладнання", count: 89 },
      { id: "14-11", title: "Хімічна сировина", count: 67 },
      { id: "14-12", title: "Токени і смарт карти", count: 23 },
      { id: "14-13", title: "Інформаційно-рекламне обладнання", count: 45 }
    ]
  },
  {
    id: "15",
    title: "Товари для свята",
    desc: "Святкові товари та подарунки",
    image: "https://images.pexels.com/photos/1303081/pexels-photo-1303081.jpeg?auto=compress&cs=tinysrgb&w=800",
    subcategories: [
      { id: "15-1", title: "Настільні ігри", count: 234 },
      { id: "15-2", title: "Набори для покеру", count: 45 },
      { id: "15-3", title: "Спортивні ігри", count: 123 },
      { id: "15-4", title: "Аксесуари для настільних ігор", count: 67 },
      { id: "15-5", title: "Штучні сосни та ялинки", count: 89 },
      { id: "15-6", title: "Новорічний декор", count: 345 },
      { id: "15-7", title: "Сувеніри", count: 456 },
      { id: "15-8", title: "Антистреси", count: 123 },
      { id: "15-9", title: "Шахи, шашки, нарди", count: 78 },
      { id: "15-10", title: "Подарунки для новонароджених", count: 156 },
      { id: "15-11", title: "Товари для свят", count: 234 },
      { id: "15-12", title: "Квіти", count: 189 },
      { id: "15-13", title: "Гральні карти", count: 67 },
      { id: "15-14", title: "Карти Таро", count: 34 },
      { id: "15-15", title: "Листівки", count: 123 },
      { id: "15-16", title: "Подарункові упаковки", count: 234 },
      { id: "15-17", title: "Товари для весілля", count: 156 },
      { id: "15-18", title: "Міні-бари", count: 45 },
      { id: "15-19", title: "Консервовані подарунки", count: 23 },
      { id: "15-20", title: "Прапори і аксесуари", count: 89 },
      { id: "15-21", title: "Подарункові набори", count: 234 },
      { id: "15-22", title: "Головоломки", count: 123 },
      { id: "15-23", title: "Екокуби", count: 56 }
    ]
  }
];