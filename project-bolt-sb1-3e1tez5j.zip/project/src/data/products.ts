import { Product } from '../types';

// Mock products data with manufacturers, prices, and discounts
export const products: Product[] = [
  // Laptops and Computer Peripherals
  {
    id: "1",
    name: "Ноутбук ASUS VivoBook 15",
    price: 18999,
    originalPrice: 22999,
    discount: 17,
    manufacturer: "ASUS",
    image: "https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 156,
    categoryId: "1",
    subcategoryId: "1-1"
  },
  {
    id: "2",
    name: "Монітор Samsung 24'' Full HD",
    price: 4599,
    manufacturer: "Samsung",
    image: "https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 89,
    categoryId: "1",
    subcategoryId: "1-3"
  },
  {
    id: "3",
    name: "Планшет Apple iPad Air",
    price: 21999,
    originalPrice: 24999,
    discount: 12,
    manufacturer: "Apple",
    image: "https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 234,
    categoryId: "1",
    subcategoryId: "1-4"
  },
  // Smartphones and Electronics
  {
    id: "4",
    name: "iPhone 15 Pro 128GB",
    price: 42999,
    manufacturer: "Apple",
    image: "https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 567,
    categoryId: "2",
    subcategoryId: "2-1"
  },
  {
    id: "5",
    name: "Samsung Galaxy S24 Ultra",
    price: 38999,
    originalPrice: 44999,
    discount: 13,
    manufacturer: "Samsung",
    image: "https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 423,
    categoryId: "2",
    subcategoryId: "2-1"
  },
  {
    id: "6",
    name: "Телевізор LG OLED 55''",
    price: 35999,
    originalPrice: 42999,
    discount: 16,
    manufacturer: "LG",
    image: "https://images.pexels.com/photos/1201996/pexels-photo-1201996.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 189,
    categoryId: "2",
    subcategoryId: "2-3"
  },
  // Home Appliances
  {
    id: "7",
    name: "Холодильник Bosch Side-by-Side",
    price: 28999,
    manufacturer: "Bosch",
    image: "https://images.pexels.com/photos/4686822/pexels-photo-4686822.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 98,
    categoryId: "3",
    subcategoryId: "3-1"
  },
  {
    id: "8",
    name: "Пральна машина Whirlpool 8кг",
    price: 15999,
    originalPrice: 18999,
    discount: 16,
    manufacturer: "Whirlpool",
    image: "https://images.pexels.com/photos/4239091/pexels-photo-4239091.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 145,
    categoryId: "3",
    subcategoryId: "3-1"
  },
  // Fashion
  {
    id: "9",
    name: "Кросівки Nike Air Max",
    price: 3299,
    originalPrice: 3999,
    discount: 18,
    manufacturer: "Nike",
    image: "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 234,
    categoryId: "5",
    subcategoryId: "5-2"
  },
  {
    id: "10",
    name: "Куртка Adidas Originals",
    price: 2799,
    manufacturer: "Adidas",
    image: "https://images.pexels.com/photos/994517/pexels-photo-994517.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 167,
    categoryId: "5",
    subcategoryId: "5-1"
  },
  // Home Goods
  {
    id: "11",
    name: "Диван IKEA Ektorp",
    price: 12999,
    originalPrice: 15999,
    discount: 19,
    manufacturer: "IKEA",
    image: "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4,
    reviews: 89,
    categoryId: "6",
    subcategoryId: "6-1"
  },
  {
    id: "12",
    name: "Набір посуду Tefal 12 предметів",
    price: 2499,
    manufacturer: "Tefal",
    image: "https://images.pexels.com/photos/4226796/pexels-photo-4226796.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 5,
    reviews: 123,
    categoryId: "6",
    subcategoryId: "6-2"
  }
];

// Get unique manufacturers from products
export const getManufacturers = (): string[] => {
  const manufacturers = products.map(product => product.manufacturer);
  return [...new Set(manufacturers)].sort();
};

// Get price range from products
export const getPriceRange = (): { min: number; max: number } => {
  const prices = products.map(product => product.price);
  return {
    min: Math.min(...prices),
    max: Math.max(...prices)
  };
};