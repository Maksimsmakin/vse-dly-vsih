import { Language } from '../types';

export const translations = {
  uk: {
    brand: 'Є Все Для Всіх',
    nav: {
      home: 'Головна', 
      catalog: 'Каталог',
      cart: 'Кошик',
      contacts: 'Контакти'
    },
    hero: {
      title: 'Інтернет-магазин "Є Все Для Всіх"',
      subtitle: 'Великий вибір товарів для дому, роботи та відпочинку. Швидка доставка по всій Україні.',
      cta: 'Переглянути каталог'
    },
    categories: {
      title: 'Категорії товарів',
      gadgets: {
        title: 'Гаджети',
        desc: 'Останні новинки за доступною ціною.'
      },
      fashion: {
        title: 'Одяг',
        desc: 'Стиль і тренди від постачальників напряму.'
      },
      home: {
        title: 'Для дому',
        desc: 'Товари для затишку і комфорту в кожному домі.'
      },
      addToCart: 'Додати в кошик'
    },
    checkout: {
      title: 'Оформлення замовлення',
      emptyCart: 'Ваш кошик порожній',
      namePlaceholder: 'Ім\'я',
      phonePlaceholder: 'Телефон',
      addressPlaceholder: 'Адреса доставки',
      confirmOrder: 'Підтвердити замовлення',
      thankYou: 'Дякуємо за замовлення!'
    },
    footer: {
      copyright: '© 2025 LuxDrop. Всі права захищені.'
    }
  },
  ru: {
    brand: 'Есть Всё Для Всех',
    nav: {
      home: 'Главная',
      catalog: 'Каталог',
      cart: 'Корзина',
      contacts: 'Контакты'
    },
    hero: {
      title: 'Интернет-магазин "Есть Всё Для Всех"',
      subtitle: 'Большой выбор товаров для дома, работы и отдыха. Быстрая доставка по всей Украине.',
      cta: 'Посмотреть каталог'
    },
    categories: {
      title: 'Категории товаров',
      gadgets: {
        title: 'Гаджеты',
        desc: 'Последние новинки по доступной цене.'
      },
      fashion: {
        title: 'Одежда',
        desc: 'Стиль и тренды от поставщиков напрямую.'
      },
      home: {
        title: 'Для дома',
        desc: 'Товары для уюта и комфорта в каждом доме.'
      },
      addToCart: 'Добавить в корзину'
    },
    checkout: {
      title: 'Оформление заказа',
      emptyCart: 'Ваша корзина пуста',
      namePlaceholder: 'Имя',
      phonePlaceholder: 'Телефон',
      addressPlaceholder: 'Адрес доставки',
      confirmOrder: 'Подтвердить заказ',
      thankYou: 'Спасибо за заказ!'
    },
    footer: {
      copyright: '© 2025 LuxDrop. Все права защищены.'
    }
  },
  en: {
    brand: 'Everything For Everyone',
    nav: {
      home: 'Home',
      catalog: 'Catalog',
      cart: 'Cart',
      contacts: 'Contacts'
    },
    hero: {
      title: 'Online Store "Everything For Everyone"',
      subtitle: 'Wide selection of products for home, work and leisure. Fast delivery throughout Ukraine.',
      cta: 'View Catalog'
    },
    categories: {
      title: 'Product Categories',
      gadgets: {
        title: 'Gadgets',
        desc: 'Latest innovations at affordable prices.'
      },
      fashion: {
        title: 'Fashion',
        desc: 'Style and trends directly from suppliers.'
      },
      home: {
        title: 'Home',
        desc: 'Products for comfort in every home.'
      },
      addToCart: 'Add to Cart'
    },
    checkout: {
      title: 'Order Checkout',
      emptyCart: 'Your cart is empty',
      namePlaceholder: 'Name',
      phonePlaceholder: 'Phone',
      addressPlaceholder: 'Delivery Address',
      confirmOrder: 'Confirm Order',
      thankYou: 'Thank you for your order!'
    },
    footer: {
      copyright: '© 2025 LuxDrop. All rights reserved.'
    }
  }
};