export interface Category {
  id: string;
  title: string;
  desc: string;
  image: string;
  price?: string;
  subcategories?: Subcategory[];
}

export interface Subcategory {
  id: string;
  title: string;
  count?: number;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  manufacturer: string;
  image: string;
  rating: number;
  reviews: number;
  categoryId: string;
  subcategoryId?: string;
}

export interface FilterState {
  manufacturers: string[];
  priceRange: {
    min: number;
    max: number;
  };
  onlyDiscounted: boolean;
}

export interface CartItem extends Category {
  quantity: number;
}

export interface FormData {
  name: string;
  phone: string;
  address: string;
}

export type Language = 'uk' | 'ru' | 'en';